import{p as e,t as p}from"../../chunks/_layout-79cb23d1.js";export{e as prerender,p as trailingSlash};
