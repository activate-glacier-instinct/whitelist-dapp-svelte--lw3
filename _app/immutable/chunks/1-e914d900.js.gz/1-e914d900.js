import{default as t}from"../components/error.svelte-a1a75c3f.js";export{t as component};
