import{_ as r}from"./_layout-79cb23d1.js";import{default as t}from"../components/pages/_layout.svelte-3b56df44.js";export{t as component,r as universal};
