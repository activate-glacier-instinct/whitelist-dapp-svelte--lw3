import{default as t}from"../components/pages/_page.svelte-c92c60fe.js";export{t as component};
